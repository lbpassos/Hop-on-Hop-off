package pt.ulisboa.tecnico.cmu.expandabletest;

/**
 * Created by ist426300 on 08-05-2018.
 */

import java.util.ArrayList;

public class GroupItemsInfo {

    private String question;
    private ArrayList<ChildItemsInfo> list;

    public GroupItemsInfo(String q){
        this.question = q;
        list = new ArrayList<ChildItemsInfo>();
    }

    public String getQuestion() {
        return question;
    }

    public void addChild(ChildItemsInfo ci){
        list.add(ci);
    }

    public ArrayList<ChildItemsInfo> getChilds() {
        return list;
    }

}
