package pt.ulisboa.tecnico.cmu.expandabletest;

/**
 * Created by ist426300 on 08-05-2018.
 */

//Each choice
public class ChildItemsInfo {

    private String option;
    private String position;

    public ChildItemsInfo(String option, String pos){
        this.option = option;
        this.position = pos;
    }
    public String getName() {
        return option;
    }
    public String getPosition() {
        return position;
    }

}